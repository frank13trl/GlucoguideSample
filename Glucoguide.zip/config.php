<?php
$host="localhost";
$dbuser="root";
$dbpass="";
$dbname="glucoguide";
$handle= mysqli_connect($host, $dbuser, $dbpass, $dbname);